//package com.codeflo.llm;
//
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.io.OutputStream;
//import java.io.InputStream;
//import java.util.Scanner;
//
//public class GeminiAPI {
//    private static final String API_KEY = "AIzaSyCHpB03oxUwUcDgqsDhpXKhf1iWIRAK1xo";
//    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + API_KEY;
//
//    public static String getGeminiResponse(String prompt) {
//        try {
//            URL url = new URL(API_URL);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//
//            conn.setRequestMethod("POST");
//            conn.setRequestProperty("Content-Type", "application/json");
//            conn.setDoOutput(true);
//
//            String payload = """
//                {
//                  "contents": [{
//                    "parts": [{
//                      "text": "%s"
//                    }]
//                  }]
//                }
//                """.formatted(prompt.replace("\"", "\\\""));
//
//            try (OutputStream os = conn.getOutputStream()) {
//                os.write(payload.getBytes());
//                os.flush();
//            }
//
//            if (conn.getResponseCode() != 200) {
//                return "❌ Error: HTTP " + conn.getResponseCode();
//            }
//
//            try (InputStream is = conn.getInputStream();
//                 Scanner scanner = new Scanner(is)) {
//                scanner.useDelimiter("\\A");
//                String responseBody = scanner.hasNext() ? scanner.next() : "";
//
//                // Extract text response from JSON
//                int start = responseBody.indexOf("\"text\":\"");
//                int end = responseBody.indexOf("\"", start + 8);
//                if (start != -1 && end != -1) {
//                    return responseBody.substring(start + 8, end).replace("\\n", "\n");
//                }
//
//                return "⚠️ Response received but couldn't parse output.";
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "❌ Error occurred during Gemini API call.";
//        }
//    }
//}

package com.codeflo.llm;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.Scanner;

public class GeminiAPI {
    private static final String API_KEY = "AIzaSyCHpB03oxUwUcDgqsDhpXKhf1iWIRAK1xo";
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

    public static String getGeminiResponse(String prompt) {
        try {
            // Prepare the payload with the prompt
            JSONObject payload = new JSONObject()
                    .put("contents", new JSONArray().put(new JSONObject()
                            .put("parts", new JSONArray().put(new JSONObject().put("text", prompt)))
                    ));

            // Set up the connection
            URL url = new URL(API_URL + "?key=" + API_KEY);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            // Write the JSON payload
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes());
                os.flush();
            }

            // Check if the response code is OK (HTTP 200)
            if (conn.getResponseCode() != 200) {
                return "❌ Error: HTTP " + conn.getResponseCode();
            }

            // Read the response from Gemini
            try (InputStream is = conn.getInputStream();
                 Scanner scanner = new Scanner(is)) {
                scanner.useDelimiter("\\A");
                String responseBody = scanner.hasNext() ? scanner.next() : "";

                // Parse the response to extract the text content
                JSONObject resJson = new JSONObject(responseBody);
                JSONArray candidates = resJson.optJSONArray("candidates");

                // Check if candidates are returned and extract the response text
                if (candidates != null && !candidates.isEmpty()) {
                    JSONObject firstCandidate = candidates.getJSONObject(0);
                    JSONObject content = firstCandidate.getJSONObject("content");
                    JSONArray parts = content.getJSONArray("parts");
                    return parts.getJSONObject(0).optString("text", "⚠️ No response content found.");
                } else {
                    return "⚠️ No candidates returned.";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "⚠️ Error: " + e.getMessage();
        }
    }
}
