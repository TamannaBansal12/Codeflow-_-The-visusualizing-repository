package com.codeflo.llm;

public class LLMHandler {
    public static String analyzeCode(String codeSnippet) {
        String prompt = "Analyze the following Java code and summarize its functionality. Also, mention time complexity if possible:\n\n" + codeSnippet;
        return GeminiAPI.getGeminiResponse(prompt);
    }

    public static String getCodeSuggestions(String codeSnippet) {
        String prompt = "Suggest code improvements or refactorings for the following Java code:\n\n" + codeSnippet;
        return GeminiAPI.getGeminiResponse(prompt);
    }

    public static String detectInfiniteLoops(String codeSnippet) {
        String prompt = "Does this Java code contain any infinite loops or suspicious patterns?\n\n" + codeSnippet;
        return GeminiAPI.getGeminiResponse(prompt);
    }
}
