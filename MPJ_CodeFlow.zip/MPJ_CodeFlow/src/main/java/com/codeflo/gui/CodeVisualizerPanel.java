package com.codeflo.gui;

import com.codeflo.parser.JavaCodeParser;
import com.codeflo.visualizer.FlowchartGenerator;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.util.List;

public class CodeVisualizerPanel extends JPanel {
    private static DefaultListModel<String> fileListModel = new DefaultListModel<>();
    private static JList<String> fileList = new JList<>(fileListModel);

    private JButton loadFileButton;
    private JPanel graphPanel;

    public CodeVisualizerPanel() {
        setLayout(new BorderLayout());

        loadFileButton = new JButton("Load Java File");
        loadFileButton.addActionListener(e -> loadJavaFile());

        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.add(loadFileButton, BorderLayout.NORTH);

        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fileList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedFileName = fileList.getSelectedValue();
                if (selectedFileName != null) {
                    File file = new File(System.getProperty("user.home") + "/codeflo_repos", selectedFileName);
                    if (file.exists()) visualizeJavaFile(file);
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(fileList);
        scrollPane.setPreferredSize(new Dimension(200, 0));
        controlPanel.add(scrollPane, BorderLayout.CENTER);

        graphPanel = new JPanel(new BorderLayout());
        add(controlPanel, BorderLayout.WEST);
        add(graphPanel, BorderLayout.CENTER);
    }

    private void loadJavaFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Java Files", "java"));
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            visualizeJavaFile(selectedFile);
        }
    }

    private void visualizeJavaFile(File file) {
        List<JavaCodeParser.Element> elements = JavaCodeParser.parseJavaFile(file);
        graphPanel.removeAll();
        graphPanel.add(new FlowchartGenerator(elements), BorderLayout.CENTER);
        graphPanel.revalidate();
        graphPanel.repaint();
    }

    public static void addFileToList(String fileName) {
        SwingUtilities.invokeLater(() -> fileListModel.addElement(fileName));
    }
}
