package com.codeflo.gui;

import com.codeflo.github.GitHubHandler;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JTextField repoUrlField;
    private JButton fetchButton;

    public MainFrame() {
        setTitle("CodeFlow - GitHub Repository Viewer & Visualizer");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel for Repo Fetching
        JPanel fetchPanel = new JPanel(new FlowLayout());
        repoUrlField = new JTextField(30);
        fetchButton = new JButton("Fetch Repository");

        fetchButton.addActionListener(e -> {
            String url = repoUrlField.getText();
            GitHubHandler.fetchAndStoreRepository(url);
        });

        fetchPanel.add(new JLabel("GitHub Repo URL:"));
        fetchPanel.add(repoUrlField);
        fetchPanel.add(fetchButton);

        // Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Repository Fetcher", fetchPanel);
        tabbedPane.addTab("Code Visualizer", new CodeVisualizerPanel());

        // ✅ New LLM Assistant Panel
        tabbedPane.addTab("LLM Assistant", new LLMPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }
}
