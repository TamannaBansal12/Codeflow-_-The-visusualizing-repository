package com.codeflo.gui;

import com.codeflo.llm.LLMHandler;

import javax.swing.*;
import java.awt.*;

public class LLMPanel extends JPanel {
    private final JTextArea inputArea;
    private final JTextArea outputArea;

    public LLMPanel() {
        setLayout(new BorderLayout());

        inputArea = new JTextArea(15, 80);
        outputArea = new JTextArea(15, 80);
        outputArea.setEditable(false);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton analyzeBtn = new JButton("Analyze Code");
        JButton refactorBtn = new JButton("Suggest Improvements");
        JButton detectBtn = new JButton("Detect Infinite Loops");

        analyzeBtn.addActionListener(e -> handleRequest("analyze"));
        refactorBtn.addActionListener(e -> handleRequest("refactor"));
        detectBtn.addActionListener(e -> handleRequest("detect"));

        buttonPanel.add(analyzeBtn);
        buttonPanel.add(refactorBtn);
        buttonPanel.add(detectBtn);

        add(new JScrollPane(inputArea), BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(new JScrollPane(outputArea), BorderLayout.SOUTH);
    }

    private void handleRequest(String type) {
        String input = inputArea.getText().trim();
        if (input.isEmpty()) {
            outputArea.setText("⚠️ Please enter some code first.");
            return;
        }

        outputArea.setText("🔄 Fetching response from Gemini...");
        SwingUtilities.invokeLater(() -> {
            String result;
            switch (type) {
                case "analyze" -> result = LLMHandler.analyzeCode(input);
                case "refactor" -> result = LLMHandler.getCodeSuggestions(input);
                case "detect" -> result = LLMHandler.detectInfiniteLoops(input);
                default -> result = "Unknown action.";
            }
            outputArea.setText(result);
        });
    }
}
