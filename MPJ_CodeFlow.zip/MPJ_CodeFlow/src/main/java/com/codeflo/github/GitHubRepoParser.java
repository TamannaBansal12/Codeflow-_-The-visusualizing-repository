package com.codeflo.github;

import com.codeflo.database.DatabaseManager;
import com.codeflo.gui.CodeVisualizerPanel;
import org.kohsuke.github.*;

import java.io.IOException;

public class GitHubRepoParser {

    public static void parseRepo(GHRepository repo, int repoId) {
        try {
            for (GHContent content : repo.getDirectoryContent("")) {
                if (content.isFile() && content.getName().endsWith(".java")) {
                    processFile(content, repoId);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processFile(GHContent file, int repoId) {
        try {
            String content = file.getContent();
            int fileId = DatabaseManager.insertFile(repoId, file.getName(), file.getPath(), content);

            if (fileId == -1) {
                System.err.println("❌ Skipping method parsing: file insert failed for " + file.getName());
                return;
            }

            parseMethods(file.getName(), content, fileId);
            CodeVisualizerPanel.addFileToList(file.getName());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void parseMethods(String fileName, String content, int fileId) {
        String[] lines = content.split("\\n");

        for (int i = 0; i < lines.length; i++) {
            if (lines[i].trim().matches(".*(public|private|protected|static).*\\(.*\\)\\s*\\{")) {
                String[] parts = lines[i].split("\\(")[0].trim().split(" ");
                String methodName = parts[parts.length - 1];

                DatabaseManager.insertMethod(fileId, methodName, i + 1, i + 10);
            }
        }
    }
}
