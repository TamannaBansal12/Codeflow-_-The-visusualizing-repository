package com.codeflo.github;

import com.codeflo.database.DatabaseManager;
import org.kohsuke.github.*;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GitHubHandler {
    public static void fetchAndStoreRepository(String repoUrl) {
        try {
            String[] parts = parseRepoUrl(repoUrl);
            if (parts == null) {
                System.err.println("❌ Invalid GitHub repository URL.");
                return;
            }

            String owner = parts[0];
            String repoName = parts[1];

            GitHub github = new GitHubBuilder().build();
            GHRepository repo = github.getRepository(owner + "/" + repoName);

            String repoPath = Paths.get(System.getProperty("user.home"), "codeflo_repos", repoName).toString();

            int repoId = DatabaseManager.insertRepository(repo.getName(), repo.getHtmlUrl().toString(), repoPath);
            if (repoId == -1) {
                System.err.println("❌ Failed to insert repository. Aborting...");
                return;
            }

            GitHubRepoParser.parseRepo(repo, repoId);

            System.out.println("✅ Repository cloned and stored successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String[] parseRepoUrl(String url) {
        Pattern pattern = Pattern.compile("github\\.com/([^/]+)/([^/]+)");
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            return new String[]{matcher.group(1), matcher.group(2)};
        }
        return null;
    }
}
