package com.codeflo.database;

import java.sql.*;

public class DatabaseManager {
    private static final String URL = "jdbc:postgresql://localhost:5432/codeflo_db";
    private static final String USER = "postgres";
    private static final String PASSWORD = "ghana";

    static {
        createTables();
    }

    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static void createTables() {
        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(SQLQueries.CREATE_REPOSITORIES_TABLE);
            stmt.execute(SQLQueries.CREATE_FILES_TABLE);
            stmt.execute(SQLQueries.CREATE_METHODS_TABLE);
            stmt.execute(SQLQueries.CREATE_VISUALIZATIONS_TABLE);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int insertRepository(String name, String url, String repoPath) {
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQLQueries.INSERT_REPO)) {
            pstmt.setString(1, name);
            pstmt.setString(2, url);
            pstmt.setString(3, repoPath);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static int insertFile(int repoId, String filename, String path, String content) {
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQLQueries.INSERT_FILE, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, repoId);
            pstmt.setString(2, filename);
            pstmt.setString(3, path);
            pstmt.setString(4, content);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static void insertMethod(int fileId, String methodName, int startLine, int endLine) {
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQLQueries.INSERT_METHOD)) {
            pstmt.setInt(1, fileId);
            pstmt.setString(2, methodName);
            pstmt.setInt(3, startLine);
            pstmt.setInt(4, endLine);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void insertVisualization(int repoId, String jsonData) {
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(SQLQueries.INSERT_VISUALIZATION)) {
            pstmt.setInt(1, repoId);
            pstmt.setString(2, jsonData);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
