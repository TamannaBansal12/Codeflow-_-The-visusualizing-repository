package com.codeflo.database;

public class SQLQueries {
    public static final String CREATE_REPOSITORIES_TABLE = """
        CREATE TABLE IF NOT EXISTS repositories (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            path TEXT NOT NULL
        );
    """;

    public static final String CREATE_FILES_TABLE = """
        CREATE TABLE IF NOT EXISTS files (
            id SERIAL PRIMARY KEY,
            repo_id INTEGER REFERENCES repositories(id) ON DELETE CASCADE,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            content TEXT
        );
    """;

    public static final String CREATE_METHODS_TABLE = """
        CREATE TABLE IF NOT EXISTS methods (
            id SERIAL PRIMARY KEY,
            file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
            method_name TEXT NOT NULL,
            start_line INTEGER,
            end_line INTEGER
        );
    """;

    public static final String CREATE_VISUALIZATIONS_TABLE = """
        CREATE TABLE IF NOT EXISTS visualizations (
            id SERIAL PRIMARY KEY,
            repo_id INTEGER REFERENCES repositories(id) ON DELETE CASCADE,
            json_data TEXT NOT NULL
        );
    """;

    public static final String INSERT_REPO = """
        INSERT INTO repositories (name, url, path) VALUES (?, ?, ?) RETURNING id;
    """;

    public static final String INSERT_FILE = """
        INSERT INTO files (repo_id, filename, path, content) VALUES (?, ?, ?, ?);
    """;

    public static final String INSERT_METHOD = """
        INSERT INTO methods (file_id, method_name, start_line, end_line) VALUES (?, ?, ?, ?);
    """;

    public static final String INSERT_VISUALIZATION = """
        INSERT INTO visualizations (repo_id, json_data) VALUES (?, ?);
    """;
}
