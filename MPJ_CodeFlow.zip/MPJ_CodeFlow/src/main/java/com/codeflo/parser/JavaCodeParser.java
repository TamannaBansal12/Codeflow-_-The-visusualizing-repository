package com.codeflo.parser;

import com.github.javaparser.*;
import com.github.javaparser.ast.*;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.stmt.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class JavaCodeParser {
    public static List<Element> parseJavaFile(File file) {
        List<Element> elements = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(file);
            CompilationUnit cu = StaticJavaParser.parse(fis);

            // Extract classes and methods
            cu.findAll(ClassOrInterfaceDeclaration.class).forEach(cls -> {
                elements.add(new Element("Class", cls.getNameAsString()));
                cls.getMethods().forEach(method -> elements.add(new Element("Method", method.getNameAsString())));
            });

            // Extract loops and conditionals
            cu.findAll(IfStmt.class).forEach(ifStmt -> elements.add(new Element("If Condition", "If")));
            cu.findAll(ForStmt.class).forEach(forStmt -> elements.add(new Element("For Loop", "For")));
            cu.findAll(WhileStmt.class).forEach(whileStmt -> elements.add(new Element("While Loop", "While")));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return elements;
    }

    // Inner class to hold element details (type and name)
    public static class Element {
        private String type;
        private String name;

        public Element(String type, String name) {
            this.type = type;
            this.name = name;
        }

        public String getType() {
            return type;
        }

        public String getName() {
            return name;
        }
    }
}
