package com.codeflo.visualizer;

import com.codeflo.parser.JavaCodeParser;

import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FlowchartGenerator extends JPanel {
    private mxGraph graph;
    private Object parent;

    public FlowchartGenerator(List<JavaCodeParser.Element> elements) {
        setLayout(new BorderLayout()); // Ensures full expansion

        graph = new mxGraph();
        parent = graph.getDefaultParent();
        generateGraph(elements);

        mxGraphComponent graphComponent = new mxGraphComponent(graph);
        graphComponent.setConnectable(false);
        graphComponent.getGraph().setAllowDanglingEdges(false);
        graphComponent.setDragEnabled(false);

        add(graphComponent, BorderLayout.CENTER);

        // Optional: Zoom to fit
        SwingUtilities.invokeLater(graphComponent::zoomAndCenter);
    }

    private void generateGraph(List<JavaCodeParser.Element> elements) {
        graph.getModel().beginUpdate();
        try {
            Object previousNode = null;
            int x = 100;
            int y = 50;
            int verticalSpacing = 80;

            for (JavaCodeParser.Element element : elements) {
                // Differentiate appearance based on the element type
                Color color;
                String label = element.getName();

                switch (element.getType()) {
                    case "Class":
                        color = Color.CYAN;  // Light blue for classes
                        break;
                    case "Method":
                        color = Color.GREEN; // Green for methods
                        label = "Method: " + label;
                        break;
                    case "If Condition":
                        color = Color.YELLOW; // Yellow for if conditions
                        label = "If Condition";
                        break;
                    case "For Loop":
                        color = Color.ORANGE; // Orange for loops
                        label = "For Loop";
                        break;
                    case "While Loop":
                        color = Color.PINK; // Pink for while loops
                        label = "While Loop";
                        break;
                    default:
                        color = Color.GRAY; // Default color for unknown
                        break;
                }

                // Create node with appropriate color
                Object node = graph.insertVertex(parent, null, label, x, y, 200, 50);
                graph.getModel().setStyle(node, "fillColor=" + toHex(color));


                if (previousNode != null) {
                    graph.insertEdge(parent, null, "", previousNode, node);
                }
                previousNode = node;
                y += verticalSpacing;
            }
        } finally {
            graph.getModel().endUpdate();
        }
    }

    // Convert color to hex string
    private String toHex(Color color) {
        return "#" + Integer.toHexString(color.getRGB()).substring(2).toUpperCase();
    }
}
