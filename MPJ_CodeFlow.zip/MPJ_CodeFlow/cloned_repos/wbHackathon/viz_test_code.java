package com.codeflo.test;

import java.util.*;

public class ComplexSample {

    // Main execution entry
    public static void main(String[] args) {
        ComplexSample sample = new ComplexSample();
        sample.run();
    }

    // Multi-layered execution function
    public void run() {
        List<DataNode> nodes = generateNodes(10);
        processNodes(nodes);
        calculateResults(nodes);
    }

    // Generates a list of sample DataNode objects
    private List<DataNode> generateNodes(int count) {
        List<DataNode> nodes = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            nodes.add(new DataNode("Node-" + i, i * 10));
        }
        return nodes;
    }

    // Processes nodes with different strategies
    private void processNodes(List<DataNode> nodes) {
        for (DataNode node : nodes) {
            if (node.value % 2 == 0) {
                node.processEven();
            } else {
                node.processOdd();
            }
        }
    }

    // Computes final result with complex branching
    private void calculateResults(List<DataNode> nodes) {
        int total = 0;
        for (DataNode node : nodes) {
            total += node.value;
            if (node.value > 50) {
                node.markHighValue();
            }
        }
        System.out.println("Total Value: " + total);
    }

    // Inner static class for handling node data
    static class DataNode {
        String name;
        int value;
        boolean processed = false;

        public DataNode(String name, int value) {
            this.name = name;
            this.value = value;
        }

        public void processEven() {
            System.out.println(name + " processed as EVEN.");
            this.value += 5;
            this.processed = true;
        }

        public void processOdd() {
            System.out.println(name + " processed as ODD.");
            this.value *= 2;
            this.processed = true;
        }

        public void markHighValue() {
            System.out.println(name + " marked as HIGH value.");
        }
    }
}
